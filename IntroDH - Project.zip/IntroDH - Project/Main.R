library (rjson)
library(plotly)
library(ggmap)
library (eurostat)
library(sf)
library(terra)
library(dplyr)
library(spData)
library(leaflet)
library(sp)
library(rgdal)
library (geojsonio)
library(leaflet.extras)
library(htmlTable)
library(rjson)
library(tidyverse)
library(concaveman)

#the code should be fully runnable and does not contain any errors. just select all and execute it. it takes around a minute
#after executing the code, a map will be shown


#load tram stops for Dresden -------------------

tramstopsDresden <- fromJSON(file = "CityData/tramstopsDresden.json")
tramstopsDresdenelements = tramstopsDresden$elements

tramstopsDresdenlat =c()
tramstopsDresdenlong = c()

for(i in 1:length(tramstopsDresdenelements)) {
  
  tramstopsDresdenlat <- c(tramstopsDresdenlat, tramstopsDresdenelements[[i]]$lat)
  tramstopsDresdenlong <- c(tramstopsDresdenlong, tramstopsDresdenelements[[i]]$lon)
}      


#load train stops for Dresden -------------------

railwaystopDresden <- fromJSON(file = "CityData/railwaystopDresden.json")
railwaystopDresdenelements = railwaystopDresden$elements

railwaystopDresdenlat =c()
railwaystopDresdenlong = c()

for(i in 1:length(railwaystopDresdenelements)) {
  
  railwaystopDresdenlat <- c(railwaystopDresdenlat, railwaystopDresdenelements[[i]]$lat)
  railwaystopDresdenlong <- c(railwaystopDresdenlong, railwaystopDresdenelements[[i]]$lon)
} 

#load bus stops for Dresden -------------------

busstopsDresden <- fromJSON(file = "CityData/busstopsDresden.json")
busstopsDresdenelements = busstopsDresden$elements

busstopsDresdenlat =c()
busstopsDresdenlong = c()

for(i in 1:length(busstopsDresdenelements)) {
  
  busstopsDresdenlat <- c(busstopsDresdenlat, busstopsDresdenelements[[i]]$lat)
  busstopsDresdenlong <- c(busstopsDresdenlong, busstopsDresdenelements[[i]]$lon)
}     


#load tram stops for Leipzig -------------------

tramstopsLeipzig <- fromJSON(file = "CityData/tramstopsLeipzig.json")
tramstopsLeipzigelements = tramstopsLeipzig$elements

tramstopsLeipziglat =c()
tramstopsLeipziglong = c()


for(i in 1:length(tramstopsLeipzigelements)) {
  
  tramstopsLeipziglat <- c(tramstopsLeipziglat, tramstopsLeipzigelements[[i]]$lat)
  tramstopsLeipziglong <- c(tramstopsLeipziglong, tramstopsLeipzigelements[[i]]$lon)
}      

#load train stops for Leipzig -------------------

railwaystopLeipzig <- fromJSON(file = "CityData/railwaystopLeipzig.json")
railwaystopLeipzigelements = railwaystopLeipzig$elements

railwaystopLeipziglat =c()
railwaystopLeipziglong = c()

for(i in 1:length(railwaystopLeipzigelements)) {
  
  railwaystopLeipziglat <- c(railwaystopLeipziglat, railwaystopLeipzigelements[[i]]$lat)
  railwaystopLeipziglong <- c(railwaystopLeipziglong, railwaystopLeipzigelements[[i]]$lon)
} 

#load bus stops for Leipzig -------------------

busstopsLeipzig <- fromJSON(file = "CityData/busstopsLeipzig.json")
busstopsLeipzigelements = busstopsLeipzig$elements

busstopsLeipziglat =c()
busstopsLeipziglong = c()

for(i in 1:length(busstopsLeipzigelements)) {
  
  busstopsLeipziglat <- c(busstopsLeipziglat, busstopsLeipzigelements[[i]]$lat)
  busstopsLeipziglong <- c(busstopsLeipziglong, busstopsLeipzigelements[[i]]$lon)
}     



# Create a dataframe with points of the stops for Dresden -------------------
tramstopsDresdendf <- data.frame(lon = tramstopsDresdenlong,
                                 lat = tramstopsDresdenlat)


busstopsDresdendf <- data.frame(lon = busstopsDresdenlong,
                                lat = busstopsDresdenlat)

railwaystopsDresdendf <- data.frame(lon = railwaystopDresdenlong,
                                    lat = railwaystopDresdenlat)


#create a dataframe with points of stops for Leipzig -------------------
tramstopsLeipzigdf <- data.frame(lon = tramstopsLeipziglong,
                                 lat = tramstopsLeipziglat)


busstopsLeipzigdf <- data.frame(lon = busstopsLeipziglong,
                                lat = busstopsLeipziglat)

railwaystopsLeipzigdf <- data.frame(lon = railwaystopLeipziglong,
                                    lat = railwaystopLeipziglat)


# Load my GeoJSON boundary files -------------------
  
boundariesDresden <- fromJSON(file = "CityData/DresdenEditedTeilen.geojson")
boundariesLeipzig <- fromJSON(file = "CityData/Leipzig.geojson")


#add Einkommen property to the boundary files so i can show it as a popup window on the map for Leipzig -------------

einkommenLeipzig <- as.data.frame(read.csv("CityData/Leipzig_Einkommen.csv", head = TRUE, sep = ";"))


boundariesLeipzigEinkommen = data.frame()
boundariesLeipzigEinkommen = boundariesLeipzig

for(i in 1:length(boundariesLeipzig$features)) {
  for (j in 1:length(einkommenLeipzig[["Stadtteilnummer"]])){
    if (!is.null(boundariesLeipzig[["features"]][[i]][["properties"]][["OT"]])){
      if (as.integer(boundariesLeipzig[["features"]][[i]][["properties"]][["OT"]]) == as.integer(einkommenLeipzig[["Stadtteilnummer"]][j])){

        boundariesLeipzigEinkommen[["features"]][[i]][["properties"]][["Einkommen"]] = append(boundariesLeipzigEinkommen[["features"]][[i]][["properties"]][["Einkommen"]], einkommenLeipzig[["X2021"]][j])
        
        }
    }
  }
}

#add Einkommen property to the boundary files so i can show it as a popup window on the map for Dresden -------------

einkommenDresden <- as.data.frame(read.csv("CityData/Dresden_Einkommen.csv", head = TRUE, sep=";"))

boundariesDresdenEinkommen = data.frame()
boundariesDresdenEinkommen = boundariesDresden

for(i in 1:length(boundariesDresden$features)) {
  for (j in 1:length(einkommenDresden[["Stadtraumnummer"]])){
    if (!is.null(boundariesDresden[["features"]][[i]][["properties"]][["bez"]])){
      if (as.integer(boundariesDresden[["features"]][[i]][["properties"]][["blocknr"]]) == as.integer(einkommenDresden[["Stadtraumnummer"]][j])){
        
        boundariesDresdenEinkommen[["features"]][[i]][["properties"]][["Einkommen"]] = append(boundariesDresdenEinkommen[["features"]][[i]][["properties"]][["Einkommen"]], einkommenDresden[["Einkommen.Haushalt"]][j])
      }
    }
  }
}


#Calculate the number of stops for each mean of transport for each city district in Leipzig and add it to the database so i can display it as a popup window --------

boundariesLeipzigEinkommenStops = data.frame()
boundariesLeipzigEinkommenStops = boundariesLeipzigEinkommen

for (k in 1: length(boundariesLeipzig[["features"]]))
{
  if (!is.null(boundariesLeipzig[["features"]][[k]][["properties"]][["Name"]]))
  {
  boundariesLeipzigdflat = data.frame()
  boundariesLeipzigdflon = data.frame()
for (i in 1:length(boundariesLeipzig[["features"]][[k]][["geometry"]][["coordinates"]][[1]])){
boundariesLeipzigdflat = append(boundariesLeipzigdflat, boundariesLeipzig[["features"]][[k]][["geometry"]][["coordinates"]][[1]][[i]][[1]])
boundariesLeipzigdflon = append(boundariesLeipzigdflon, boundariesLeipzig[["features"]][[k]][["geometry"]][["coordinates"]][[1]][[i]][[2]])
}
  
  boundariesLeipzigdf = (data.frame(col1 = as.numeric(boundariesLeipzigdflat), col2 = as.numeric(boundariesLeipzigdflon)))
  
  boundariesLeipzigsf = st_as_sf(boundariesLeipzigdf,
                                 coords = c("col1","col2"))
  
  LeipzigArea = concaveman(boundariesLeipzigsf)
 
  tramstopsLeipzigsf = st_as_sf(x = tramstopsLeipzigdf,
                                coords = c('lon', 'lat'))
  
  busstopsLeipzigsf = st_as_sf(x = busstopsLeipzigdf,
                                coords = c('lon', 'lat'))
  
  railwaystopsLeipzigsf = st_as_sf(x = railwaystopsLeipzigdf,
                                coords = c('lon', 'lat'))

  tramstopsLeipzigWithin = st_within(tramstopsLeipzigsf, LeipzigArea)
  tramstopsLeipzigInside = sum(nchar(tramstopsLeipzigWithin) == 1)
  
  busstopsLeipzigWithin = st_within(busstopsLeipzigsf, LeipzigArea)
  busstopsLeipzigInside = sum(nchar(busstopsLeipzigWithin) == 1)
  
  railwaystopsLeipzigWithin = st_within(railwaystopsLeipzigsf, LeipzigArea)
  railwaystopsLeipzigInside = sum(nchar(railwaystopsLeipzigWithin) == 1)
  
  for(n in 1:length(boundariesLeipzigEinkommen$features)) {
    if (!is.null(boundariesLeipzig[["features"]][[n]][["properties"]][["OT"]])){
        if (as.integer(boundariesLeipzigEinkommen[["features"]][[n]][["properties"]][["OT"]]) == as.integer(boundariesLeipzig[["features"]][[k]][["properties"]][["OT"]])){
          
          boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["TramStops"]] = append(boundariesLeipzigEinkommenStops[["features"]][[n]][["properties"]][["TramStops"]], tramstopsLeipzigInside)
          boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["BusStops"]] = append(boundariesLeipzigEinkommenStops[["features"]][[n]][["properties"]][["BusStops"]], busstopsLeipzigInside)
          boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["TrainStops"]] = append(boundariesLeipzigEinkommenStops[["features"]][[n]][["properties"]][["TrainStops"]], railwaystopsLeipzigInside)
          boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["AllStops"]] = append(boundariesLeipzigEinkommenStops[["features"]][[n]][["properties"]][["AllStops"]], (railwaystopsLeipzigInside+tramstopsLeipzigInside+busstopsLeipzigInside))
          
        }
      }
    }
  }
}

#Calculate the number of stops for each mean of transport for each city district in Dresden and add it to the database so i can display it as a popup window --------

boundariesDresdenEinkommenStops = data.frame()
boundariesDresdenEinkommenStops = boundariesDresdenEinkommen

for (k in 1: length(boundariesDresden[["features"]]))
{
  if (!is.null(boundariesDresden[["features"]][[k]][["properties"]][["bez"]]))
  {
    boundariesDresdendflat = data.frame()
    boundariesDresdendflon = data.frame()
    for (i in 1:length(boundariesDresden[["features"]][[k]][["geometry"]][["coordinates"]][[1]])){
      boundariesDresdendflat = append(boundariesDresdendflat, boundariesDresden[["features"]][[k]][["geometry"]][["coordinates"]][[1]][[i]][[1]])
      boundariesDresdendflon = append(boundariesDresdendflon, boundariesDresden[["features"]][[k]][["geometry"]][["coordinates"]][[1]][[i]][[2]])
       }
    
    boundariesDresdendf = (data.frame(col1 = as.numeric(boundariesDresdendflat), col2 = as.numeric(boundariesDresdendflon)))
    
    boundariesDresdensf = st_as_sf(boundariesDresdendf,
                                   coords = c("col1","col2"))
    
    DresdenArea = concaveman(boundariesDresdensf)
    
    tramstopsDresdensf = st_as_sf(x = tramstopsDresdendf,
                                  coords = c('lon', 'lat'))
    
    busstopsDresdensf = st_as_sf(x = busstopsDresdendf,
                                 coords = c('lon', 'lat'))
    
    railwaystopsDresdensf = st_as_sf(x = railwaystopsDresdendf,
                                     coords = c('lon', 'lat'))
    
    tramstopsDresdenWithin = st_within(tramstopsDresdensf, DresdenArea)
    tramstopsDresdenInside = sum(nchar(tramstopsDresdenWithin) == 1)
    
    busstopsDresdenWithin = st_within(busstopsDresdensf, DresdenArea)
    busstopsDresdenInside = sum(nchar(busstopsDresdenWithin) == 1)
    
    railwaystopsDresdenWithin = st_within(railwaystopsDresdensf, DresdenArea)
    railwaystopsDresdenInside = sum(nchar(railwaystopsDresdenWithin) == 1)
    
    for(n in 1:length(boundariesDresdenEinkommen$features)) {
      if (!is.null(boundariesDresden[["features"]][[n]][["properties"]][["bez"]])){
        if ((boundariesDresdenEinkommen[["features"]][[n]][["properties"]][["bez"]]) == (boundariesDresden[["features"]][[k]][["properties"]][["bez"]])){
          
          boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["TramStops"]] = append(boundariesDresdenEinkommenStops[["features"]][[n]][["properties"]][["TramStops"]], tramstopsDresdenInside)
          boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["BusStops"]] = append(boundariesDresdenEinkommenStops[["features"]][[n]][["properties"]][["BusStops"]], busstopsDresdenInside)
          boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["TrainStops"]] = append(boundariesDresdenEinkommenStops[["features"]][[n]][["properties"]][["TrainStops"]], railwaystopsDresdenInside)
          boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["AllStops"]] = append(boundariesDresdenEinkommenStops[["features"]][[n]][["properties"]][["AllStops"]], (railwaystopsDresdenInside+tramstopsDresdenInside+busstopsDresdenInside))
  
        }
      }
    }
  }
}

#Now, using the leaflet extension, create a map for Dresden and Leipzig districts ---------------------------

map <- leaflet(options = leafletOptions(zoomControl = TRUE,
                                        zoomSnap = 0.25,
                                        zoomDelta = 1)) %>% 
  addProviderTiles(providers$CartoDB.Positron)%>% 
  setView(lng = 10.3, lat = 50.9, zoom = 6)%>% 
  addGeoJSONChoropleth(boundariesDresdenEinkommenStops,
             color = '#3d3d3d',
             scale = c("white", "#3279a8"),
             steps = 55,
             opacity = 0.6,
             weight = 1,
             valueProperty = "Einkommen",
            # fillColor = '00FFFFFF',
             fillOpacity = 0.3,
             popupProperty = JS("function(feature){
                   return ('<h2>'+feature.properties.bez+'</h2>'+'Household Income (Avg. Euro): '+feature.properties.Einkommen +'<br><br>Number of Tram Stops: '+parseInt(feature.properties.TramStops).toFixed(2)+'<br>Number of Bus Stops: '+parseInt(feature.properties.BusStops).toFixed(2)+'<br>Number of Train Stops: '+parseInt(feature.properties.TrainStops).toFixed(2)+'<br>Number of All Stops: '+parseInt(feature.properties.AllStops).toFixed(2)+
                    '<br><br>Tram Stops per 1000 Euro: '+((parseInt(feature.properties.TramStops)/parseInt(feature.properties.Einkommen))*1000).toFixed(2)+'<br>Bus Stops per 1000 Euro: '+((feature.properties.BusStops/parseInt(feature.properties.Einkommen))*1000).toFixed(2) +'<br>Train Stops per 1000 Euro '+((feature.properties.TrainStops/parseInt(feature.properties.Einkommen))*1000).toFixed(2) + '<br>Stops per 1000 Euro: '+((feature.properties.AllStops/parseInt(feature.properties.Einkommen))*1000).toFixed(2));
                    }"))
            
#*Dresden*

map = map %>%
  addGeoJSONChoropleth(boundariesLeipzigEinkommenStops,  
               color = '#3d3d3d',
               scale = c("white", "#3279a8"),
               steps = 55,
               opacity = 0.6,
               weight = 1,
               valueProperty = "Einkommen",
               # fillColor = '00FFFFFF',
               fillOpacity = 0.3,
                    popupProperty = JS("function(feature){
                   return ('<h2>'+feature.properties.Name+'</h2>'+'Household Income (Avg. Euro): '+(feature.properties.Einkommen) +'<br><br>Number of Tram Stops: '+parseInt(feature.properties.TramStops).toFixed(2)+'<br>Number of Bus Stops: '+parseInt(feature.properties.BusStops).toFixed(2)+'<br>Number of Train Stops: '+parseInt(feature.properties.TrainStops).toFixed(2)+'<br>Number of All Stops: '+parseInt(feature.properties.AllStops).toFixed(2)+
                    '<br><br>Tram Stops per 1000 Euro: '+((parseInt(feature.properties.TramStops)/parseInt(feature.properties.Einkommen))*1000).toFixed(2)+'<br>Bus Stops per 1000 Euro: '+((feature.properties.BusStops/parseInt(feature.properties.Einkommen))*1000).toFixed(2) +'<br>Train Stops per 1000 Euro '+((feature.properties.TrainStops/parseInt(feature.properties.Einkommen))*1000).toFixed(2) + '<br>Stops per 1000 Euro: '+((feature.properties.AllStops/parseInt(feature.properties.Einkommen))*1000).toFixed(2));
                    }")) %>%
  addProviderTiles(providers$CartoDB.Positron)

#Show the map, so we know everything went fine -------------------
  
map

# Now, add points representing the stops in Dresden -----------------

map <- map %>% 
  addCircleMarkers(data = tramstopsDresdendf,
                   lng = ~lon, 
                   lat = ~lat,
                   radius = 2,
                   color = '#bfbdbd',
                   group="Tram Stops")%>%
  addCircleMarkers(data = busstopsDresdendf,
                   lng = ~lon, 
                   lat = ~lat,
                   radius = 2,
                   color = '#3e567d',
                   group="Bus Stops")%>%
  addCircleMarkers(data = railwaystopsDresdendf,
                  lng = ~lon, 
                  lat = ~lat,
                  radius = 2,
                  color = '#1ce2e6',
                  group="Train Stations")%>%
  
#Now, add points representing the stops in Leipzig ----------------
  
  addCircleMarkers(data = tramstopsLeipzigdf,
                 lng = ~lon, 
                 lat = ~lat,
                 radius = 2,
                 color = '#bfbdbd',
                 group="Tram Stops")%>%
  addCircleMarkers(data = busstopsLeipzigdf,
                   lng = ~lon, 
                   lat = ~lat,
                   radius = 2,
                   color = '#3e567d',
                   group="Bus Stops")%>%
  addCircleMarkers(data = railwaystopsLeipzigdf,
                   lng = ~lon, 
                   lat = ~lat,
                   radius = 2,
                   color = '#1ce2e6',
                   group="Train Stations")


#We also want to be able to toggle the visibility of the stop groups ----------------------------

map <- map %>%
 
  addLayersControl(overlayGroups = c("Tram Stops", "Bus Stops", "Train Stations"), 
                   options = layersControlOptions(collapsed = F))

#finally, display the map ------------------------------

map





#This is not needed, but in case we want to print out some results, we use this

#for (k in 1: length(boundariesDresden[["features"]])){
 # if (!is.null(boundariesDresden[["features"]][[k]][["properties"]][["bez"]])){
  #  for(n in 1:length(boundariesDresdenEinkommen$features)) {
   #   if (!is.null(boundariesDresden[["features"]][[n]][["properties"]][["bez"]])){
    #    if ((boundariesDresdenEinkommen[["features"]][[n]][["properties"]][["bez"]]) == (boundariesDresden[["features"]][[k]][["properties"]][["bez"]])){
          
          #print("--------------------------------------------------")
          #print (boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["bez"]])
          #print("Einkommen:")
          #print (boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])
          #print("Bus Stops:")
          #print ((boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["BusStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("Train Stops:")
          #print ((boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["TrainStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("Tram Stops:")
          #print ((boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["TramStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("All Stops:")
          #print ((boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["AllStops"]]/boundariesDresdenEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
        
         #}
      #}
    #}
  #}
#}


#for (k in 1: length(boundariesLeipzig[["features"]])){
  #if (!is.null(boundariesLeipzig[["features"]][[k]][["properties"]][["Name"]])){
   # for(n in 1:length(boundariesLeipzigEinkommen$features)) {
    #  if (!is.null(boundariesLeipzig[["features"]][[n]][["properties"]][["Name"]])){
     #   if ((boundariesLeipzigEinkommen[["features"]][[n]][["properties"]][["OT"]]) == (boundariesLeipzig[["features"]][[k]][["properties"]][["OT"]])){
          
          #print("--------------------------------------------------")
          #print (boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Name"]])
          #print("Einkommen:")
          #print (boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])
          #print("Bus Stops:")
          #print ((boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["BusStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("Train Stops:")
          #print ((boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["TrainStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("Tram Stops:")
          #print ((boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["TramStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("All Stops:")
          #print ((boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["AllStops"]]/boundariesLeipzigEinkommenStops[["features"]][[k]][["properties"]][["Einkommen"]])*1000)
          #print ("-------------------")  
        #}
      #}
    #}
  #}
#}